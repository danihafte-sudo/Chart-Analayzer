# Chart Analyzer Pro

Real technical analysis from live market data, plus AI commentary and screenshot reading.

- **Live market**: real candles from Binance (crypto, no key needed). EMA 20/50/200, RSI, MACD, Bollinger, ATR, swing support/resistance, candlestick patterns and a weighted bias score are all calculated in code.
- **CSV data**: upload candles exported from any platform (time, open, high, low, close, volume).
- **Screenshot**: AI reads a chart image. Levels are visual estimates.
- **AI commentary**: Claude explains the computed numbers in plain English. It never invents values.

## Deploy (Vercel, about 5 minutes)

1. Create a free GitHub repo and upload this folder.
2. Go to vercel.com, choose Add New Project, and import the repo. Vercel detects Vite automatically.
3. Before deploying, open Environment Variables and add:
   - `ANTHROPIC_API_KEY` = your key from console.anthropic.com
   - `ANTHROPIC_MODEL` (optional, default `claude-sonnet-5-5`)
4. Deploy. Open the URL on your phone and use Share > Add to Home Screen.

## Run locally

```
npm install
npx vercel dev     # runs the site and the /api function together
```
`npm run dev` alone shows the live market and CSV tabs, but AI features need `vercel dev`.

## Notes

- The API key stays on the server (`api/analyze.js`). Never put it in `src/`.
- The function has a basic per-IP limit of 20 requests per hour. Add real login (Supabase or Clerk) before sharing publicly, since each AI call costs money.
- Stocks and forex need a paid data provider (Twelve Data, Polygon, Alpha Vantage). Swap `fetchBinance` in `src/lib/data.js` for one of them. The CSV tab works for any market today.
