// Vercel serverless function. Keeps your Anthropic API key on the server.
// Env vars: ANTHROPIC_API_KEY (required), ANTHROPIC_MODEL (optional)

const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";

// Best-effort rate limit per IP (resets when the function instance recycles).
const hits = new Map();
const LIMIT = 20;
const WINDOW_MS = 60 * 60 * 1000;
function limited(ip) {
  const now = Date.now();
  const rec = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  rec.push(now);
  hits.set(ip, rec);
  return rec.length > LIMIT;
}

const COMMENTARY_PROMPT = `You are a senior technical analyst writing for retail traders.
You receive indicator values computed from real price data. Use ONLY the numbers provided. Never invent levels or indicators.
Do not predict the future or give financial advice. Describe conditions, what confirms each scenario, and what invalidates it.
Respond with ONLY a JSON object, no markdown, in this shape:
{"headline": "one sentence",
 "summary": "3-4 plain-English sentences",
 "bull_case": "1-2 sentences with specific levels from the data",
 "bear_case": "1-2 sentences with specific levels from the data",
 "watch": ["3 short things to watch next"],
 "risk": "1 sentence on volatility and invalidation, using ATR if provided"}`;

const IMAGE_PROMPT = `You are an expert technical analyst. The user uploads a screenshot of a trading chart. Analyze only what is visible.
Respond with ONLY a JSON object, no markdown, in this shape:
{"asset": "string or 'Unknown'", "timeframe": "string or 'Unknown'",
 "trend": "bullish" | "bearish" | "sideways", "confidence": 0-100,
 "summary": "2-3 plain-English sentences",
 "support": ["price level with short note"], "resistance": ["price level with short note"],
 "patterns": [{"name": "", "note": ""}],
 "indicators": [{"name": "", "note": "say 'not visible' if absent"}],
 "bullish_case": "1-2 sentences", "bearish_case": "1-2 sentences", "risk_note": "1 sentence"}
Read price levels from the chart axis. Never invent indicators that are not shown.
If the image is not a trading chart, return {"error": "This doesn't look like a trading chart."}.`;

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed." });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: "Server is missing ANTHROPIC_API_KEY." });

  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
  if (limited(ip)) return res.status(429).json({ error: "Too many requests. Try again in a while." });

  try {
    const { mode, summary, image, note } = req.body || {};
    let system;
    let content;

    if (mode === "image") {
      if (!image || typeof image !== "string" || image.length > 6_000_000) {
        return res.status(400).json({ error: "Send a JPEG image under 4 MB." });
      }
      system = IMAGE_PROMPT;
      content = [
        { type: "image", source: { type: "base64", media_type: "image/jpeg", data: image } },
        { type: "text", text: note ? `Analyze this chart. Trader context: ${String(note).slice(0, 300)}` : "Analyze this chart." },
      ];
    } else if (mode === "commentary") {
      if (!summary || typeof summary !== "object") return res.status(400).json({ error: "Missing analysis data." });
      system = COMMENTARY_PROMPT;
      content = `Computed analysis data:\n${JSON.stringify(summary).slice(0, 8000)}`;
    } else {
      return res.status(400).json({ error: "Unknown mode." });
    }

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 1200, system, messages: [{ role: "user", content }] }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: data?.error?.message || "AI request failed." });

    const text = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join("");
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return res.status(502).json({ error: "AI returned an unreadable response." });
    return res.status(200).json(JSON.parse(match[0]));
  } catch (e) {
    return res.status(500).json({ error: "Analysis failed. Please try again." });
  }
}
