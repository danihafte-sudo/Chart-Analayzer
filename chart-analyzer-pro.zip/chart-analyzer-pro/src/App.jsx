import { useEffect, useMemo, useRef, useState } from "react";
import CandleChart from "./components/CandleChart.jsx";
import { analyze, fmt } from "./lib/indicators.js";
import { fetchBinance, parseCSV, compressImage } from "./lib/data.js";

const QUICK = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", "PAXGUSDT", "EURUSDT"];
const TFS = ["5m", "15m", "1h", "4h", "1d"];

async function callApi(body) {
  const r = await fetch("/api/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "AI service is unavailable.");
  if (d.error) throw new Error(d.error);
  return d;
}

const tone = (score) => (score >= 15 ? "up" : score <= -15 ? "down" : "flat");

function Tile({ label, value, sub, kind }) {
  return (
    <div className="tile">
      <span className="tile-label">{label}</span>
      <strong className={`tile-value ${kind || ""}`}>{value}</strong>
      <span className="tile-sub">{sub}</span>
    </div>
  );
}

function Gauge({ score }) {
  const pos = ((score + 100) / 200) * 100;
  return (
    <div className="gauge" aria-label={`Bias score ${score} out of 100`}>
      <div className="gauge-track">
        <div className="gauge-mid" />
        <div className="gauge-dot" style={{ left: `${pos}%` }} />
      </div>
      <div className="gauge-scale"><span>Bearish</span><span>Neutral</span><span>Bullish</span></div>
    </div>
  );
}

function Levels({ title, list, kind }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      {list.length === 0 ? (
        <p className="muted">No clear levels in this range.</p>
      ) : (
        <table className="levels">
          <thead><tr><th>Price</th><th>Distance</th><th>Touches</th></tr></thead>
          <tbody>
            {list.map((l, i) => (
              <tr key={i}>
                <td className={kind}>{fmt(l.price)}</td>
                <td>{l.distPct > 0 ? "+" : ""}{l.distPct.toFixed(2)}%</td>
                <td>{l.touches}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function ImageResult({ r }) {
  const kind = r.trend === "bullish" ? "up" : r.trend === "bearish" ? "down" : "flat";
  return (
    <div className="stack">
      <div className="card">
        <div className="row-between">
          <div>
            <p className="muted">{r.asset} · {r.timeframe}</p>
            <h2 className={`big ${kind}`}>{r.trend?.[0]?.toUpperCase() + r.trend?.slice(1)}</h2>
          </div>
          <div className="right"><p className="muted">Confidence</p><h2 className="big">{Math.round(r.confidence)}%</h2></div>
        </div>
        <p className="body">{r.summary}</p>
      </div>
      <div className="grid2">
        <div className="card"><h3>Support</h3><ul className="plain">{(r.support || []).map((s, i) => <li key={i}>{s}</li>)}</ul></div>
        <div className="card"><h3>Resistance</h3><ul className="plain">{(r.resistance || []).map((s, i) => <li key={i}>{s}</li>)}</ul></div>
      </div>
      <div className="card">
        <h3>Patterns and indicators</h3>
        <ul className="plain">
          {(r.patterns || []).map((p, i) => <li key={`p${i}`}><b>{p.name}.</b> {p.note}</li>)}
          {(r.indicators || []).map((p, i) => <li key={`i${i}`}><b>{p.name}.</b> {p.note}</li>)}
        </ul>
      </div>
      <div className="grid2">
        <div className="card"><h3>Bullish if</h3><p className="body">{r.bullish_case}</p></div>
        <div className="card"><h3>Bearish if</h3><p className="body">{r.bearish_case}</p></div>
      </div>
      <p className="warn">{r.risk_note}</p>
    </div>
  );
}

export default function App() {
  const [source, setSource] = useState("market");
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [tf, setTf] = useState("1h");
  const [candles, setCandles] = useState(null);
  const [label, setLabel] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [ai, setAi] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState("");
  const [image, setImage] = useState(null);
  const [note, setNote] = useState("");
  const [imgResult, setImgResult] = useState(null);
  const csvRef = useRef(null);
  const imgRef = useRef(null);

  const analysis = useMemo(() => (candles ? analyze(candles) : null), [candles]);

  const loadMarket = async (sym = symbol, interval = tf) => {
    setLoading(true);
    setError("");
    setAi(null);
    setAiError("");
    try {
      const data = await fetchBinance(sym, interval, 500);
      setCandles(data);
      setLabel(`${sym.toUpperCase()} · ${interval}`);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMarket("BTCUSDT", "1h");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onCsv = async (file) => {
    if (!file) return;
    setError("");
    setAi(null);
    try {
      const rows = parseCSV(await file.text());
      setCandles(rows);
      setLabel(file.name);
    } catch (e) {
      setError(e.message);
    }
  };

  const onImage = async (file) => {
    if (!file) return;
    setError("");
    setImgResult(null);
    if (!file.type.startsWith("image/")) return setError("Upload a PNG, JPG or WebP image.");
    try {
      setImage(await compressImage(file));
    } catch (e) {
      setError(e.message);
    }
  };

  const runImage = async () => {
    setLoading(true);
    setError("");
    setImgResult(null);
    try {
      setImgResult(await callApi({ mode: "image", image: image.base64, note }));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const runCommentary = async () => {
    if (!analysis) return;
    setAiLoading(true);
    setAiError("");
    try {
      const a = analysis;
      const summary = {
        instrument: label,
        price: a.price,
        bias: a.bias,
        score: a.score,
        trend: a.trend,
        structure: a.structure,
        ema: a.ema,
        rsi: a.rsi,
        macd: a.macd,
        bollingerPctB: a.bb.pctB,
        atr: a.atr,
        atrPct: a.atrPct,
        relativeVolume: a.volRel,
        support: a.support,
        resistance: a.resistance,
        patterns: a.patterns.map((p) => p.name),
        signals: a.signals.map((s) => ({ name: s.name, vote: s.vote, reading: s.reading })),
      };
      setAi(await callApi({ mode: "commentary", summary }));
    } catch (e) {
      setAiError(e.message);
    } finally {
      setAiLoading(false);
    }
  };

  const switchSource = (s) => {
    setSource(s);
    setError("");
  };

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <span className="logo" aria-hidden="true">
            <i style={{ height: 10 }} /><i style={{ height: 18 }} /><i style={{ height: 13 }} />
          </span>
          <span>Chart Analyzer Pro</span>
        </div>
        <nav className="tabs" role="tablist">
          {[["market", "Live market"], ["csv", "CSV data"], ["image", "Screenshot"]].map(([k, t]) => (
            <button key={k} role="tab" aria-selected={source === k} className={source === k ? "on" : ""} onClick={() => switchSource(k)}>{t}</button>
          ))}
        </nav>
      </header>

      <main className="wrap">
        {source === "market" && (
          <section className="controls">
            <div className="field">
              <label htmlFor="sym">Symbol</label>
              <div className="inline">
                <input id="sym" value={symbol} onChange={(e) => setSymbol(e.target.value.toUpperCase())} onKeyDown={(e) => e.key === "Enter" && loadMarket()} autoCapitalize="characters" spellCheck="false" />
                <button className="primary" onClick={() => loadMarket()} disabled={loading}>{loading ? "Loading" : "Analyze"}</button>
              </div>
            </div>
            <div className="chips">
              {QUICK.map((q) => (
                <button key={q} className={`chip ${symbol === q ? "on" : ""}`} onClick={() => { setSymbol(q); loadMarket(q, tf); }}>{q.replace("USDT", "")}</button>
              ))}
            </div>
            <div className="chips">
              {TFS.map((t) => (
                <button key={t} className={`chip ${tf === t ? "on" : ""}`} onClick={() => { setTf(t); loadMarket(symbol, t); }}>{t}</button>
              ))}
            </div>
          </section>
        )}

        {source === "csv" && (
          <section className="controls">
            <p className="muted">Upload candles exported from any platform. Needs columns for time, open, high, low and close (volume optional), with at least 60 rows.</p>
            <button className="primary" onClick={() => csvRef.current?.click()}>Choose CSV file</button>
            <input ref={csvRef} type="file" accept=".csv,text/csv" hidden onChange={(e) => onCsv(e.target.files?.[0])} />
          </section>
        )}

        {source === "image" && (
          <section className="controls">
            <p className="muted">AI reads a chart screenshot. Levels are visual estimates, so use Live market or CSV for exact indicator values.</p>
            {!image ? (
              <button className="drop" onClick={() => imgRef.current?.click()}>Tap to upload a chart screenshot</button>
            ) : (
              <div className="preview">
                <img src={image.dataUrl} alt="Uploaded chart" />
                <button className="x" aria-label="Remove image" onClick={() => { setImage(null); setImgResult(null); }}>×</button>
              </div>
            )}
            <input ref={imgRef} type="file" accept="image/*" hidden onChange={(e) => onImage(e.target.files?.[0])} />
            {image && (
              <>
                <input className="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional: pair, timeframe, what you are looking for" />
                <button className="primary" onClick={runImage} disabled={loading}>{loading ? "Analyzing" : "Analyze screenshot"}</button>
              </>
            )}
          </section>
        )}

        {error && <div className="error" role="alert">{error}</div>}

        {source === "image" && imgResult && <ImageResult r={imgResult} />}

        {source !== "image" && loading && !analysis && <div className="skeleton">Loading market data</div>}

        {source !== "image" && analysis && (
          <div className="stack">
            <section className="card hero">
              <div className="row-between">
                <div>
                  <p className="muted">{label}</p>
                  <h1 className="price">{fmt(analysis.price)}</h1>
                  <p className={`muted ${analysis.changePct >= 0 ? "up" : "down"}`}>
                    {analysis.changePct >= 0 ? "+" : ""}{analysis.changePct.toFixed(2)}% over loaded period
                  </p>
                </div>
                <div className="right">
                  <p className="muted">Bias</p>
                  <h2 className={`big ${tone(analysis.score)}`}>{analysis.bias}</h2>
                  <p className="muted">Score {analysis.score > 0 ? "+" : ""}{analysis.score}</p>
                </div>
              </div>
              <Gauge score={analysis.score} />
            </section>

            <section className="card flush">
              <CandleChart candles={candles} analysis={analysis} bars={120} />
            </section>

            <section className="tiles">
              <Tile label="Trend" value={analysis.trend} sub={analysis.structure} kind={tone(analysis.score)} />
              <Tile label="RSI 14" value={analysis.rsi?.toFixed(1)} sub={analysis.rsi >= 70 ? "Overbought" : analysis.rsi <= 30 ? "Oversold" : "Neutral range"} />
              <Tile label="MACD" value={analysis.macd.hist > 0 ? "Positive" : "Negative"} sub={analysis.macd.read} kind={analysis.macd.hist > 0 ? "up" : "down"} />
              <Tile label="ATR 14" value={fmt(analysis.atr)} sub={`${analysis.atrPct.toFixed(2)}% of price`} />
              <Tile label="Volume" value={analysis.volRel ? `${analysis.volRel.toFixed(2)}x` : "-"} sub="Last closed bar vs 20-bar average" />
              <Tile label="Bollinger %B" value={`${Math.round(analysis.bb.pctB * 100)}%`} sub={`${fmt(analysis.bb.lower)} to ${fmt(analysis.bb.upper)}`} />
            </section>

            <section className="card">
              <h3>How the bias is scored</h3>
              <ul className="signals">
                {analysis.signals.map((s) => (
                  <li key={s.name}>
                    <div className="sig-head"><span>{s.name}</span><small>weight {s.weight}%</small></div>
                    <div className="sig-bar" aria-hidden="true">
                      <div className={s.vote >= 0 ? "pos" : "neg"} style={{ width: `${Math.abs(s.vote) * 50}%`, [s.vote >= 0 ? "left" : "right"]: "50%" }} />
                    </div>
                    <p className="muted">{s.reading}</p>
                  </li>
                ))}
              </ul>
            </section>

            <div className="grid2">
              <Levels title="Support" list={analysis.support} kind="up" />
              <Levels title="Resistance" list={analysis.resistance} kind="down" />
            </div>

            <section className="card">
              <h3>Candlestick patterns (last candles)</h3>
              {analysis.patterns.length === 0 ? (
                <p className="muted">No clear pattern on the latest candles.</p>
              ) : (
                <ul className="plain">
                  {analysis.patterns.map((p) => (
                    <li key={p.name}><b className={p.bias > 0 ? "up" : p.bias < 0 ? "down" : ""}>{p.name}.</b> {p.note}</li>
                  ))}
                </ul>
              )}
            </section>

            <section className="card">
              <div className="row-between">
                <h3>AI commentary</h3>
                <button className="ghost" onClick={runCommentary} disabled={aiLoading}>{aiLoading ? "Writing" : ai ? "Refresh" : "Generate"}</button>
              </div>
              {!ai && !aiError && !aiLoading && <p className="muted">Get a plain-English read of the numbers above, written from the computed data only.</p>}
              {aiError && <p className="down">{aiError}</p>}
              {ai && (
                <div className="stack tight">
                  <p className="body"><b>{ai.headline}</b></p>
                  <p className="body">{ai.summary}</p>
                  <p className="body"><b className="up">Bullish if.</b> {ai.bull_case}</p>
                  <p className="body"><b className="down">Bearish if.</b> {ai.bear_case}</p>
                  {ai.watch?.length > 0 && <ul className="plain">{ai.watch.map((w, i) => <li key={i}>{w}</li>)}</ul>}
                  <p className="warn">{ai.risk}</p>
                </div>
              )}
            </section>
          </div>
        )}

        <footer className="foot">
          Educational analysis only, not financial advice. Indicators are calculated from the data shown and can lag or fail. Trading carries risk of loss.
        </footer>
      </main>
    </div>
  );
}
