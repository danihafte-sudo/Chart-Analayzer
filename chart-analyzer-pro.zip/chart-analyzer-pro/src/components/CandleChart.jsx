import { useEffect, useRef } from "react";
import { fmt } from "../lib/indicators.js";

const UP = "#26d9a0";
const DN = "#ff5d73";
const GRID = "rgba(148,163,184,0.12)";
const TXT = "#7d8aa3";

function timeLabel(t, span) {
  const d = new Date(t);
  if (span > 5 * 86400000) return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  return d.toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });
}

export default function CandleChart({ candles, analysis, bars = 120 }) {
  const canvasRef = useRef(null);
  const boxRef = useRef(null);

  useEffect(() => {
    const draw = () => {
      const canvas = canvasRef.current;
      const box = boxRef.current;
      if (!canvas || !box || !candles?.length || !analysis) return;

      const W = box.clientWidth;
      const H = Math.round(Math.max(440, Math.min(640, W * 1.15)));
      const dpr = window.devicePixelRatio || 1;
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      const g = canvas.getContext("2d");
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, W, H);
      g.font = "11px system-ui, sans-serif";

      const start = Math.max(0, candles.length - bars);
      const vis = candles.slice(start);
      const n = vis.length;
      const S = analysis.series;
      const sl = (arr) => arr.slice(start);

      const axisW = 62;
      const left = 4;
      const plotW = W - axisW - left;
      const step = plotW / n;
      const cw = Math.max(1, step * 0.68);
      const X = (i) => left + i * step + step / 2;

      const gap = 10;
      const bottomPad = 18;
      const usable = H - bottomPad - gap * 2;
      const pPrice = { top: 4, h: usable * 0.58 };
      const pRsi = { top: pPrice.top + pPrice.h + gap, h: usable * 0.17 };
      const pMacd = { top: pRsi.top + pRsi.h + gap, h: usable * 0.25 - 4 };

      const line = (arr, panel, min, max, color, width = 1.4) => {
        g.beginPath();
        g.strokeStyle = color;
        g.lineWidth = width;
        let started = false;
        arr.forEach((val, i) => {
          if (val == null) return;
          const y = panel.top + panel.h - ((val - min) / (max - min)) * panel.h;
          if (!started) { g.moveTo(X(i), y); started = true; } else g.lineTo(X(i), y);
        });
        g.stroke();
      };

      const grid = (panel, min, max, ticks, label) => {
        g.strokeStyle = GRID;
        g.lineWidth = 1;
        g.fillStyle = TXT;
        g.textAlign = "left";
        for (let k = 0; k <= ticks; k++) {
          const val = min + ((max - min) * k) / ticks;
          const y = panel.top + panel.h - (k / ticks) * panel.h;
          g.beginPath();
          g.moveTo(left, y);
          g.lineTo(left + plotW, y);
          g.stroke();
          g.fillText(label(val), left + plotW + 6, y + 4);
        }
        g.strokeStyle = "rgba(148,163,184,0.25)";
        g.strokeRect(left, panel.top, plotW, panel.h);
      };

      // ---- Price panel ----
      const hi = Math.max(...vis.map((x) => x.h));
      const lo = Math.min(...vis.map((x) => x.l));
      const padP = (hi - lo) * 0.06;
      const pMax = hi + padP;
      const pMin = lo - padP;
      const PY = (p) => pPrice.top + pPrice.h - ((p - pMin) / (pMax - pMin)) * pPrice.h;
      grid(pPrice, pMin, pMax, 5, fmt);

      // volume
      const vMax = Math.max(...vis.map((x) => x.v), 1);
      vis.forEach((x, i) => {
        const bh = (x.v / vMax) * pPrice.h * 0.16;
        g.fillStyle = x.c >= x.o ? "rgba(38,217,160,0.22)" : "rgba(255,93,115,0.22)";
        g.fillRect(X(i) - cw / 2, pPrice.top + pPrice.h - bh, cw, bh);
      });

      // support / resistance
      const drawLevel = (price, color, text) => {
        if (price < pMin || price > pMax) return;
        const y = PY(price);
        g.save();
        g.setLineDash([5, 4]);
        g.strokeStyle = color;
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(left, y);
        g.lineTo(left + plotW, y);
        g.stroke();
        g.restore();
        g.fillStyle = color;
        g.fillRect(left + plotW + 1, y - 8, axisW - 2, 16);
        g.fillStyle = "#0a0f1a";
        g.textAlign = "left";
        g.fillText(text, left + plotW + 5, y + 4);
      };
      analysis.support.forEach((l) => drawLevel(l.price, "rgba(38,217,160,0.85)", fmt(l.price)));
      analysis.resistance.forEach((l) => drawLevel(l.price, "rgba(255,93,115,0.85)", fmt(l.price)));

      // candles
      vis.forEach((x, i) => {
        const up = x.c >= x.o;
        g.strokeStyle = g.fillStyle = up ? UP : DN;
        g.lineWidth = 1;
        g.beginPath();
        g.moveTo(X(i), PY(x.h));
        g.lineTo(X(i), PY(x.l));
        g.stroke();
        const yO = PY(x.o);
        const yC = PY(x.c);
        g.fillRect(X(i) - cw / 2, Math.min(yO, yC), cw, Math.max(1, Math.abs(yO - yC)));
      });

      // moving averages
      line(sl(S.e20), pPrice, pMin, pMax, "#f5c451");
      line(sl(S.e50), pPrice, pMin, pMax, "#5aa9ff");
      if (S.e200[candles.length - 1] != null) line(sl(S.e200), pPrice, pMin, pMax, "#c58bff");

      // last price tag
      const lastC = vis[n - 1];
      const yLast = PY(lastC.c);
      g.save();
      g.setLineDash([2, 3]);
      g.strokeStyle = "rgba(226,232,240,0.6)";
      g.beginPath();
      g.moveTo(left, yLast);
      g.lineTo(left + plotW, yLast);
      g.stroke();
      g.restore();
      g.fillStyle = lastC.c >= lastC.o ? UP : DN;
      g.fillRect(left + plotW + 1, yLast - 9, axisW - 2, 18);
      g.fillStyle = "#06101a";
      g.font = "bold 11px system-ui, sans-serif";
      g.fillText(fmt(lastC.c), left + plotW + 5, yLast + 4);
      g.font = "11px system-ui, sans-serif";

      // legend
      g.textAlign = "left";
      const legend = [["EMA 20", "#f5c451"], ["EMA 50", "#5aa9ff"], ["EMA 200", "#c58bff"]];
      let lx = left + 8;
      legend.forEach(([t, col]) => {
        g.fillStyle = col;
        g.fillRect(lx, pPrice.top + 9, 10, 3);
        g.fillStyle = TXT;
        g.fillText(t, lx + 14, pPrice.top + 14);
        lx += 66;
      });

      // ---- RSI ----
      grid(pRsi, 0, 100, 2, (x) => `${Math.round(x)}`);
      g.save();
      g.setLineDash([4, 4]);
      g.strokeStyle = "rgba(148,163,184,0.35)";
      [30, 70].forEach((lv) => {
        const y = pRsi.top + pRsi.h - (lv / 100) * pRsi.h;
        g.beginPath();
        g.moveTo(left, y);
        g.lineTo(left + plotW, y);
        g.stroke();
      });
      g.restore();
      line(sl(S.rsi), pRsi, 0, 100, "#a78bfa", 1.5);
      g.fillStyle = TXT;
      g.fillText("RSI 14", left + 8, pRsi.top + 14);

      // ---- MACD ----
      const mh = sl(S.macd.hist);
      const ml = sl(S.macd.line);
      const ms = sl(S.macd.signal);
      const all = [...mh, ...ml, ...ms].filter((x) => x != null);
      const mAbs = Math.max(...all.map(Math.abs), 1e-9) * 1.1;
      grid(pMacd, -mAbs, mAbs, 2, (x) => (Math.abs(x) >= 1 ? x.toFixed(1) : x.toPrecision(2)));
      const y0 = pMacd.top + pMacd.h / 2;
      mh.forEach((val, i) => {
        if (val == null) return;
        const hgt = (val / mAbs) * (pMacd.h / 2);
        g.fillStyle = val >= 0 ? "rgba(38,217,160,0.55)" : "rgba(255,93,115,0.55)";
        g.fillRect(X(i) - cw / 2, hgt >= 0 ? y0 - hgt : y0, cw, Math.max(1, Math.abs(hgt)));
      });
      line(ml, pMacd, -mAbs, mAbs, "#5aa9ff", 1.3);
      line(ms, pMacd, -mAbs, mAbs, "#f5c451", 1.3);
      g.fillStyle = TXT;
      g.fillText("MACD 12, 26, 9", left + 8, pMacd.top + 14);

      // time labels
      g.fillStyle = TXT;
      g.textAlign = "center";
      const span = vis[n - 1].t - vis[0].t;
      const labels = W < 480 ? 3 : 5;
      for (let k = 0; k < labels; k++) {
        const idx = Math.round((k / (labels - 1)) * (n - 1));
        g.fillText(timeLabel(vis[idx].t, span), Math.min(Math.max(X(idx), 36), left + plotW - 36), H - 4);
      }
    };

    draw();
    const ro = new ResizeObserver(draw);
    if (boxRef.current) ro.observe(boxRef.current);
    return () => ro.disconnect();
  }, [candles, analysis, bars]);

  return (
    <div ref={boxRef} className="chart-box">
      <canvas ref={canvasRef} role="img" aria-label="Candlestick chart with indicators" />
    </div>
  );
}
